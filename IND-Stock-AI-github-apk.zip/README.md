# IND Stock AI
Personal Indian stock/F&O decision aid. Not financial advice.

## Files (all at the top level of the repo)
index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png
plus .github/workflows/build-apk.yml (builds the Android APK)

## Web app (instant)
Settings > Pages > Deploy from a branch > main / root. Open the github.io link in Chrome > Install app.

## Android APK
Actions tab > Build Android APK > Run workflow. When green, download artifact IND-Stock-AI-apk, extract the zip, install app-debug.apk.
